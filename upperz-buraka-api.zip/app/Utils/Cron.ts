// import RecoveryService from 'App/Services/Recovery.service'
// import Recovery from 'App/Models/Recovery'
// import cron from 'node-cron'

// const recovery = RecoveryService
// const model = Recovery

// async function delayPayment() {
//       const data = await model.query().where('status', false)
//             .where('delay',false)
// }